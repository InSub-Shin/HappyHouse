package com.ssafy.happyhouse.dao;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.happyhouse.mapper.DealMapper;
import com.ssafy.happyhouse.model.DealInfoDto;

@Repository
public class DealInfoDaoImpl implements DealInfoDao{

	@Autowired
	DealMapper mapper;
	
	@Override
	public ArrayList<DealInfoDto> getAptInDong(String dong) throws Exception {
		return mapper.getAptInDong(dong);
	}

	@Override
	public ArrayList<DealInfoDto> getAptInApt(String apt) throws Exception {
		return mapper.getAptInApt(apt); 
	}

	@Override
	public DealInfoDto getAptInnum(String num) throws Exception {
		return mapper.getAptInnum(num);
	}

	@Override
	public ArrayList<DealInfoDto> selectAll() {
		return mapper.selectAll();
	}

}
