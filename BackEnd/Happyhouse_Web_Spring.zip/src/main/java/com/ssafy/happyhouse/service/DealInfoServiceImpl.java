package com.ssafy.happyhouse.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.happyhouse.dao.DealInfoDao;
import com.ssafy.happyhouse.model.DealInfoDto;

@Service
public class DealInfoServiceImpl implements DealInfoService{
	
	@Autowired
	DealInfoDao dao;
	
	@Override
	public ArrayList<DealInfoDto> getAptInDong(String dong) throws Exception {
		return dao.getAptInDong(dong);
	}

	@Override
	public ArrayList<DealInfoDto> getAptInApt(String apt) throws Exception {
		return dao.getAptInApt(apt); 
	}

	@Override
	public DealInfoDto selectOne(String num) throws Exception {
		return dao.getAptInnum(num);
	}

	@Override
	public ArrayList<DealInfoDto> selectAll() {
		return dao.selectAll();
	}

}
