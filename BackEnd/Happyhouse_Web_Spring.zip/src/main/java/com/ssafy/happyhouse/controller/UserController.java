package com.ssafy.happyhouse.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.ssafy.happyhouse.model.UserDto;
import com.ssafy.happyhouse.service.UserService;

@Controller
public class UserController {
	@Autowired
	UserService service;

	
	@GetMapping(value="/signup")
	public String signup() {
		return "signup";
	}

	@PostMapping(value="/signupProcess")
	public String signupProcess(HttpServletRequest request) {
		String id = request.getParameter("id");
		String password = request.getParameter("password");
		String name = request.getParameter("name");
		String address = request.getParameter("address");
		String phone = request.getParameter("phone");
		service.insert(new UserDto(null, id, password, name, address, phone));
		
		return "login";
	}

	@GetMapping(value="/login")
	public String login() {
		return "login";
	}
	
	@PostMapping(value="/loginProcess")
	public String loginProcess(HttpServletRequest request) {
		String id = request.getParameter("id");
		String password = request.getParameter("password");
		
		HttpSession session = request.getSession();
		if (service.login(id, password)) {
			session.setAttribute("id", id);
			return "index";
		} else {
			return "login";
		}
	}
	
	@GetMapping(value="/logout")
	public String logout(HttpSession session) {
		session.setAttribute("id", null);
		return "index";
	}
	
	@GetMapping(value="/mypage")
	public String myPage(HttpSession session) {
		String id = (String) session.getAttribute("id");
		UserDto user = service.selectOne(id);
		session.setAttribute("password", user.getPassword());
		session.setAttribute("name", user.getName());
		session.setAttribute("address", user.getAddress());
		session.setAttribute("phone", user.getPhone());
		
		return "mypage";
	}
	
	@GetMapping(value="/userUpdate")
	public String userUpdate() {
		return "update";
	}
	
	@PostMapping(value="/userUpdate")
	public String updateProcess(HttpServletRequest request, HttpSession session) {
		String id = (String) session.getAttribute("id");
		
		String password = request.getParameter("password");
		String name = request.getParameter("name");
		String address = request.getParameter("address");
		String phone = request.getParameter("phone");
		service.update(id, new UserDto(null, id, password, name, address, phone));

		return "mypage";
	}
	
	@GetMapping(value="/userDelete")
	public String userDelete(HttpSession session) {
		String id = (String) session.getAttribute("id");
		service.delete(id);
		session.setAttribute("id", null);
		return "index";
	}
	
	@GetMapping(value="/userlist")
	public String userList(HttpServletRequest request) {
		ArrayList<UserDto> list = service.selectAll();
		request.setAttribute("list", list);
		return "userlist";
	}	
	
	@PostMapping(value="/userSearch")
	public String userSearch(HttpServletRequest request) {
		String word = request.getParameter("word");
		ArrayList<UserDto> list = service.search(word);
		request.setAttribute("list", list);
		return "userlist";
	}
	
}
