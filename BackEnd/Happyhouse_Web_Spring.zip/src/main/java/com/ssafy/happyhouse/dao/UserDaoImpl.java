package com.ssafy.happyhouse.dao;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.happyhouse.mapper.UserMapper;
import com.ssafy.happyhouse.model.UserDto;

@Repository
public class UserDaoImpl implements UserDao {

	@Autowired
	UserMapper mapper;

	@Override
	public ArrayList<UserDto> selectAll() {
		return mapper.selectAll();
	}

	@Override
	public UserDto selectOne(String id) {
		return mapper.selectOne(id);
	}

	@Override
	public void insert(UserDto u) {
		mapper.insert(u);
	}

	@Override
	public void update(String id, UserDto u) {
		mapper.update(id, u);
	}

	@Override
	public void delete(String id) {
		mapper.delete(id);
	}

	@Override
	public boolean login(String id, String password) {
		String pw = mapper.login(id);
		if (pw.equals(password))
			return true;
		else
			return false;
	}

	@Override
	public ArrayList<UserDto> search(String word) {
		return mapper.search(word);
	}

}
