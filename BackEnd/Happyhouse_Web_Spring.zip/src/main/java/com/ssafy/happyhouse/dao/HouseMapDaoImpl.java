package com.ssafy.happyhouse.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.happyhouse.mapper.HouseMapper;
import com.ssafy.happyhouse.model.DealInfoDto;
import com.ssafy.happyhouse.model.HouseInfoDto;
import com.ssafy.happyhouse.model.SidoGugunCodeDto;

@Repository
public class HouseMapDaoImpl implements HouseMapDao {
	
	@Autowired
	HouseMapper mapper;
	
	@Override
	public List<SidoGugunCodeDto> getSido() throws Exception {
		return mapper.getSido();
	}

	@Override
	public List<SidoGugunCodeDto> getGugunInSido(String sido) throws Exception {
		return mapper.getGugunInSido(sido);
	}

	@Override
	public List<SidoGugunCodeDto> getDongInGugun(String gugun) throws Exception {
		return mapper.getDongInGugun(gugun);
	}

	@Override
	public List<DealInfoDto> getAptInDong(String dong) throws Exception {
		return mapper.getAptInDong(dong);
	}

}
