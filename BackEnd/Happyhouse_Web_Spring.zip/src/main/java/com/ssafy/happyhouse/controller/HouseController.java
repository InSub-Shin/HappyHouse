package com.ssafy.happyhouse.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.happyhouse.model.DealInfoDto;
import com.ssafy.happyhouse.model.SidoGugunCodeDto;
import com.ssafy.happyhouse.service.HouseMapService;

@RestController
@RequestMapping("/house")
public class HouseController {
	@Autowired
	HouseMapService service;
	
	@GetMapping(value="/list")
	public List<SidoGugunCodeDto> getSido() throws Exception{
		List<SidoGugunCodeDto> list = service.getSido();
		System.out.println(list.get(0));
		return list;
	}	
	
	@GetMapping(value="/{sido}")
	public List<SidoGugunCodeDto> getGugun(@PathVariable String sido) throws Exception{
		return service.getGugunInSido(sido);
	}	
	
	@GetMapping(value="/sido")
	public List<SidoGugunCodeDto> sido() throws Exception{
		List<SidoGugunCodeDto> list = service.getSido();
		return list;
	}
	
	@GetMapping(value="/gugun")
	public List<SidoGugunCodeDto> gugun(@RequestParam("sido") String sido) throws Exception{
		List<SidoGugunCodeDto> list = service.getGugunInSido(sido);
		return list;
	}
	
	@GetMapping(value="/dong")
	public List<SidoGugunCodeDto> dong(@RequestParam("gugun") String gugun) throws Exception{
		List<SidoGugunCodeDto> list = service.getDongInGugun(gugun);
		return list;
	}
	
	@GetMapping(value="/apt")
	public List<DealInfoDto> apt(@RequestParam("dong") String dong) throws Exception{
		List<DealInfoDto> list = service.getAptInDong(dong);
		return list;
	}
	
	
	
}
