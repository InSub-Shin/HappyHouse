package com.ssafy.happyhouse.mapper;

import java.util.ArrayList;

import com.ssafy.happyhouse.model.UserDto;

public interface UserMapper {
	
	public ArrayList<UserDto> selectAll();  //모든 사용자 정보
	public UserDto selectOne(String id);  //사용자 정보 조회
	public void insert(UserDto u);  //사용자 정보 등록
	public void update(String id, UserDto u);  //사용자 정보 수정
	public void delete(String id);  //사용자 정보 삭제
	public String login(String id);
	public ArrayList<UserDto> search(String word);
	
}
