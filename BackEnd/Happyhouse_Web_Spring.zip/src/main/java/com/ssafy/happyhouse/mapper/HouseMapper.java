package com.ssafy.happyhouse.mapper;

import java.util.List;

import com.ssafy.happyhouse.model.DealInfoDto;
import com.ssafy.happyhouse.model.HouseInfoDto;
import com.ssafy.happyhouse.model.SidoGugunCodeDto;

public interface HouseMapper {
	List<SidoGugunCodeDto> getSido();
	List<SidoGugunCodeDto> getGugunInSido(String sido);
	List<SidoGugunCodeDto> getDongInGugun(String gugun);
	List<DealInfoDto> getAptInDong(String dong);
}
