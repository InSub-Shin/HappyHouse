package com.ssafy.happyhouse.service;

import java.util.ArrayList;

import com.ssafy.happyhouse.model.DealInfoDto;

public interface DealInfoService {
	ArrayList<DealInfoDto> getAptInDong(String dong) throws Exception;
	ArrayList<DealInfoDto> getAptInApt(String apt) throws Exception;
	DealInfoDto selectOne(String num) throws Exception;
	ArrayList<DealInfoDto> selectAll();
}
