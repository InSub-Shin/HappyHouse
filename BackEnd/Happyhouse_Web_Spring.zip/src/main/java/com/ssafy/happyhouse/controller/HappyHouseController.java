package com.ssafy.happyhouse.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HappyHouseController {

	@GetMapping(value="/")
	public String home() {
		return "index";
	}
	
	@GetMapping(value="/sitemap")
	public String sitemap() {
		return "sitemap";
	}
	
	@GetMapping(value="/fav/add")
	public String addFav() {
		return "favoriteplace";
	}
	
	@GetMapping(value="/fav/envir")
	public String favEnvir() {
		return "favoriteplace_envir";
	}
	
	@GetMapping(value="/fav/market")
	public String favMarket() {
		return "favoriteplace_market";
	}
	
}
