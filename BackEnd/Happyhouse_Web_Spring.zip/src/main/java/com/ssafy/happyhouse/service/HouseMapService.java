package com.ssafy.happyhouse.service;

import java.util.List;

import com.ssafy.happyhouse.model.DealInfoDto;
import com.ssafy.happyhouse.model.HouseInfoDto;
import com.ssafy.happyhouse.model.SidoGugunCodeDto;

public interface HouseMapService {
	
	List<SidoGugunCodeDto> getSido() throws Exception;
	List<SidoGugunCodeDto> getGugunInSido(String sido) throws Exception;
	List<SidoGugunCodeDto> getDongInGugun(String gugun) throws Exception;
	List<DealInfoDto> getAptInDong(String dong) throws Exception;
	
}
