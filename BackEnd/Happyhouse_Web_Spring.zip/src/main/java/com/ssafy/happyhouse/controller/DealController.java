package com.ssafy.happyhouse.controller;

import java.io.IOException;


import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.happyhouse.model.UserDto;
import com.ssafy.happyhouse.service.DealInfoService;

@Controller
@RequestMapping("/deal")
public class DealController {
	@Autowired
	DealInfoService service;
	
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public String list(Model model) {		
		
		model.addAttribute("list", service.selectAll());
		
		return "deals";
	}
	
	@RequestMapping(value = "/dong", method = RequestMethod.POST)
	public String getAptInDong2(Model model,HttpServletRequest request) throws Exception{
		String dong = request.getParameter("dong");
		model.addAttribute("list", service.getAptInDong(dong));
		
		return "deals_dong";
		
	}
	
	@RequestMapping(value = "/apt", method = RequestMethod.POST)
	public String getAptInApt(HttpServletRequest request) throws Exception{
		String word = request.getParameter("word");
		request.setAttribute("list", service.getAptInApt(word));
		return "deals_dong";
		
	}
	@RequestMapping(value = "/list/{no}", method = RequestMethod.GET)
	public String selectOne(Model model,@PathVariable String no) throws Exception{
		
		model.addAttribute("b", service.selectOne(no));
		
		return "detail";
		
	}

}
