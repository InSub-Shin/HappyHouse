package com.ssafy.happyhouse.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.happyhouse.dao.UserDao;
import com.ssafy.happyhouse.dao.UserDaoImpl;
import com.ssafy.happyhouse.model.UserDto;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
	UserDao dao;

	@Override
	public ArrayList<UserDto> selectAll() {
		return dao.selectAll();
	}

	@Override
	public UserDto selectOne(String id) {
		return dao.selectOne(id);
	}

	@Override
	public void insert(UserDto u) {
		dao.insert(u);
	}

	@Override
	public void update(String id, UserDto u) {
		dao.update(id, u);
	}

	@Override
	public void delete(String id) {
		dao.delete(id);
	}

	@Override
	public boolean login(String id, String password) {
		return dao.login(id, password);
	}

	@Override
	public ArrayList<UserDto> search(String word) {
		return dao.search(word);
	}

}
