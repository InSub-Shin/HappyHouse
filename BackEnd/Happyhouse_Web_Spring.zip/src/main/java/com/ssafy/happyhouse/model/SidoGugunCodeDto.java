package com.ssafy.happyhouse.model;

public class SidoGugunCodeDto {

	private String sido_code;
	private String sido_name;
	private String gugun_code;
	private String gugun_name;
	private String dong_code;
	private String dong_name;

	public SidoGugunCodeDto() {}

	
	public SidoGugunCodeDto(String sido_code, String sido_name, String gugun_code, String gugun_name, String dong_code,
			String dong_name) {
		this.sido_code = sido_code;
		this.sido_name = sido_name;
		this.gugun_code = gugun_code;
		this.gugun_name = gugun_name;
		this.dong_code = dong_code;
		this.dong_name = dong_name;
	}


	public String getSidoCode() {
		return sido_code;
	}

	public void setSidoCode(String sidoCode) {
		this.sido_code = sidoCode;
	}

	public String getSidoName() {
		return sido_name;
	}

	public void setSidoName(String sidoName) {
		this.sido_name = sidoName;
	}

	public String getGugunCode() {
		return gugun_code;
	}

	public void setGugunCode(String gugunCode) {
		this.gugun_code = gugunCode;
	}

	public String getGugunName() {
		return gugun_name;
	}

	public void setGugunName(String gugunName) {
		this.gugun_name = gugunName;
	}

	public String getDong_code() {
		return dong_code;
	}

	public void setDong_code(String dong_code) {
		this.dong_code = dong_code;
	}

	public String getDong_name() {
		return dong_name;
	}

	public void setDong_name(String dong_name) {
		this.dong_name = dong_name;
	}

}
