package com.ssafy.happyhouse.dao;

import java.util.ArrayList;

import com.ssafy.happyhouse.model.DealInfoDto;

public interface DealInfoDao {

	ArrayList<DealInfoDto> getAptInDong(String dong) throws Exception;
	ArrayList<DealInfoDto> getAptInApt(String apt) throws Exception;
	DealInfoDto getAptInnum(String num) throws Exception;
	ArrayList<DealInfoDto> selectAll();
	
}
