package com.ssafy.happyhouse.mapper;

import java.util.ArrayList;

import com.ssafy.happyhouse.model.DealInfoDto;

public interface DealMapper {
	
	public ArrayList<DealInfoDto> getAptInDong(String dong) throws Exception;
	public ArrayList<DealInfoDto> getAptInApt(String apt) throws Exception;
	public DealInfoDto getAptInnum(String num) throws Exception;
	public ArrayList<DealInfoDto> selectAll();
	
}
